  /* Criando um componente de alert */
        /* alert ("Sejam todos bem vindos a Gama Academy");*/

        /*var empresa="Gama Academy";
        var mensagem="Sejam todos bem vindos a ";

        alert(mensagem+empresa);*/

        /* var nome=prompt("Sejam todos bem vindos a Gama Avademy, qual é o seu nome?","Insira o seu nome");
        alert("Olá "+nome+ " é um grande prazer telo você conosco");*/


        /* Criando funções em JavaScript*/
        function mensagem()
        {
            alert("oieeeeee");

        }

        function validar()
        {
            var nome=contatos.nome_cliente.value;
            var email=contatos.email_cliente.value;
            
            /*alert("O nome do cliente é "+nome+ " e o email é "+email);*/

           if(nome==""){
               alert("O preenchimento do campo nome é obrigatório");
               contatos.nome_cliente.focus();
            return false;
           }

           if(email=="" || email.indexOf('@')==-1){
               alert("O preenchimento do campo email é obrigatório, com um email válido");
               contatos.email_cliente.focus();
            return false;
           }

           alert("O nome do cliente é "+nome+ " e o email que usaremos para enviar informações do nosso curso é "+email);


        }